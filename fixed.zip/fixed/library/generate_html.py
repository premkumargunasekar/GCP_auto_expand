#!/usr/bin/python3
# -*- coding: utf-8 -*-

import json
import sys
import logging
from html import escape
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("generate_html")
logging.basicConfig(level="INFO")

# ---------------- STATUS ----------------
_STATUS_MAP = {
    "GREEN": ("ok", "OK"),
    "RED": ("crit", "CRITICAL"),
    "NO_DATA": ("na", "NO DATA"),
}

def status_class(status):
    return _STATUS_MAP.get(status, ("na", "NO DATA"))

def clean_value(val):
    if val is None:
        return "-"
    if isinstance(val, float):
        return str(round(val, 2))
    return escape(str(val))

# ---------------- CSS ----------------
CSS = """
body{font-family:Segoe UI;background:#f4f6f9;margin:20px}
h1{text-align:center}

.tabs, .component-bar{text-align:center;margin-bottom:15px}

button{padding:8px 14px;margin:5px;border:none;border-radius:6px;background:#e5e7eb;cursor:pointer}
button.active{background:#2563eb;color:#fff}
.component-btn.active{background:#059669}

.section{display:none}
.project{margin-bottom:40px}

.card{
  background:#fff;
  padding:15px;
  margin:10px 0;
  border-radius:10px;
  box-shadow:0 2px 6px rgba(0,0,0,.1)
}

.kpi-container{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}
.kpi{
  flex:1;
  min-width:150px;
  background:#fff;
  padding:15px;
  border-radius:10px;
  text-align:center;
  box-shadow:0 2px 6px rgba(0,0,0,.1)
}
.kpi.ok{border-left:6px solid green}
.kpi.crit{border-left:6px solid red}
.kpi.na{border-left:6px solid gray}

table{width:100%;border-collapse:collapse}
th{background:#111827;color:#fff;padding:10px}
td{padding:10px;border-bottom:1px solid #eee}

.ok{color:green;font-weight:bold}
.crit{color:red;font-weight:bold}
.na{color:gray;font-weight:bold}
"""

# ---------------- JS ----------------
JS = """
let currentTab = 'D1';
let currentComponent = 'all';

function show(tab){
  currentTab = tab;

  document.querySelectorAll('.section').forEach(e=>e.style.display='none');
  document.querySelectorAll('.'+tab).forEach(e=>e.style.display='block');

  document.querySelectorAll('.tabs button').forEach(b=>b.classList.remove('active'));
  document.getElementById(tab).classList.add('active');

  applyFilter();
}

function filterComponent(component){
  currentComponent = component;

  document.querySelectorAll('.component-btn').forEach(b=>b.classList.remove('active'));
  event.target.classList.add('active');

  applyFilter();
}

function applyFilter(){
  document.querySelectorAll('.section.'+currentTab+' .card.component').forEach(card=>{
    if(currentComponent === 'all'){
      card.style.display = 'block';
    } else {
      card.style.display = card.classList.contains(currentComponent) ? 'block' : 'none';
    }
  });
}

setTimeout(()=>location.reload(),5*60*1000);
"""

# ---------------- KPI ----------------
def calculate_kpi(metrics):
    ok = crit = na = 0

    if not isinstance(metrics, dict):
        return ok, crit, na

    for comp in metrics.values():

        if not isinstance(comp, dict):
            continue

        for metric in comp.values():

            # Handle flat structure (like vpc_peering)
            if isinstance(metric, dict) and "status" in metric:
                status = metric.get("status")
                if status == "GREEN":
                    ok += 1
                elif status == "RED":
                    crit += 1
                else:
                    na += 1
                continue

            if not isinstance(metric, dict):
                continue

            for win in metric.values():
                if not isinstance(win, dict):
                    continue

                status = win.get("status")

                if status == "GREEN":
                    ok += 1
                elif status == "RED":
                    crit += 1
                else:
                    na += 1

    return ok, crit, na

# ---------------- BUILD ROWS ----------------
def build_metric_rows(metric, win_entry):
    status = win_entry.get("status", "NO_DATA")
    values = win_entry.get("value")
    css, label = status_class(status)

    if not values:
        return f"<tr><td>{escape(metric)}</td><td>-</td><td>-</td><td class='{css}'>{label}</td></tr>"

    rows = ""
    for item in values:
        rows += f"""
        <tr>
            <td>{escape(metric)}</td>
            <td>{escape(str(item.get("resource", "-")))}</td>
            <td>{clean_value(item.get("value"))}</td>
            <td class="{css}">{label}</td>
        </tr>
        """
    return rows

# ---------------- DASHBOARD ----------------
def build_dashboard(data, generated_at):

    component_map = {
        "interconnect": "interconnect",
        "router": "cloud_router",
        "nat": "nat_gateway",
        "cloud_nat": "cloud_nat",
        "vpc_peering": "vpc_peering",
        "traffic": "traffic"
    }

    parts = [
        "<html><head>",
        f"<style>{CSS}</style>",
        f"<script>{JS}</script>",
        "</head><body>",

        "<h1>GCP Enterprise Dashboard</h1>",
        f"<p style='text-align:center'>Generated: {escape(generated_at)}</p>",

        "<div class='tabs'>",
        "<button id='D1' class='active' onclick=\"show('D1')\">1 Day</button>",
        "<button id='D3' onclick=\"show('D3')\">3 Days</button>",
        "<button id='D7' onclick=\"show('D7')\">7 Days</button>",
        "</div>",

        "<div class='component-bar'>",
        "<button class='component-btn active' onclick=\"filterComponent('all')\">All</button>",
        "<button class='component-btn' onclick=\"filterComponent('interconnect')\">Interconnect</button>",
        "<button class='component-btn' onclick=\"filterComponent('cloud_router')\">Cloud Router</button>",
        "<button class='component-btn' onclick=\"filterComponent('nat_gateway')\">NAT Gateway</button>",
        "<button class='component-btn' onclick=\"filterComponent('cloud_nat')\">Cloud NAT</button>",
        "<button class='component-btn' onclick=\"filterComponent('vpc_peering')\">VPC Peering</button>",
        "</div>",
    ]

    for window in ["D1", "D3", "D7"]:
        parts.append(f"<div class='section {window}'>")

        for project in data:
            parts.append("<div class='project'>")

            project_id = escape(str(project.get("project_id", "unknown")))
            parts.append(f"<h2>Project: {project_id} ({window})</h2>")

            metrics = project.get("metrics", {})
            if not isinstance(metrics, dict):
                metrics = {}

            ok, crit, na = calculate_kpi(metrics)

            parts.append("<div class='kpi-container'>")
            parts.append(f"<div class='kpi ok'>OK<br>{ok}</div>")
            parts.append(f"<div class='kpi crit'>Critical<br>{crit}</div>")
            parts.append(f"<div class='kpi na'>No Data<br>{na}</div>")
            parts.append("</div>")

            for comp, comp_metrics in metrics.items():

                css_class = component_map.get(comp, comp)
                name = escape(comp.replace("_", " ").title())

                parts.append(f"<div class='card component {css_class}'>")
                parts.append(f"<h3>{name}</h3>")
                parts.append("<table><tr><th>Metric</th><th>Resource</th><th>Value</th><th>Status</th></tr>")

                has_data = False

                if comp == "vpc_peering":
                    entry = comp_metrics.get(window)
                    if isinstance(entry, dict):
                        has_data = True
                        parts.append(build_metric_rows("vpc_peering", entry))
                else:
                    for metric, win_data in comp_metrics.items():
                        if isinstance(win_data, dict) and window in win_data:
                            has_data = True
                            parts.append(build_metric_rows(metric, win_data[window]))

                if not has_data:
                    parts.append("<tr><td colspan='4' class='na'>No Data</td></tr>")

                parts.append("</table></div>")

            parts.append("</div>")

        parts.append("</div>")

    parts.append("<script>show('D1');</script></body></html>")
    return "".join(parts)

# ---------------- MAIN ----------------
def main(input_path, output_path):
    input_file = Path(input_path)
    output_file = Path(output_path)

    if not input_file.exists():
        log.error("Input file not found: %s", input_file)
        sys.exit(1)

    with open(input_file, encoding="utf-8") as f:
        data = json.load(f)

    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    html = build_dashboard(data, generated_at)

    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    log.info("Dashboard generated: %s", output_file)
    print("HTML generated:", output_file)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.json> <output.html>")
        sys.exit(1)

    main(sys.argv[1], sys.argv[2])
