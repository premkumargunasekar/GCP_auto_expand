#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Ansible module: gcp_metrics
# Collects GCP Cloud Monitoring metrics and VPC peering status across
# multiple projects in parallel and returns structured JSON.

from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = r"""
module: gcp_metrics
short_description: Collect GCP monitoring metrics across projects
options:
  projects:
    description: List of project dicts with project_id and service_account keys.
    required: true
    type: list
  metrics:
    description: Nested dict of category → metric_name → metric config.
    required: true
    type: dict
  windows:
    description: Dict of label → seconds (e.g. D1=86400).
    required: true
    type: dict
"""

import os
import time
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from ansible.module_utils.basic import AnsibleModule

try:
    from google.cloud import monitoring_v3
    from google.oauth2 import service_account
    from google.api_core import retry as api_retry
    from google.api_core.exceptions import GoogleAPICallError, RetryError
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    HAS_GOOGLE_LIBS = True
except ImportError as e:
    HAS_GOOGLE_LIBS = False
    GOOGLE_IMPORT_ERROR = str(e)

# ---------------------------------------------------------------------------
# Logging — goes to Ansible's stdout at DEBUG level; INFO by default.
# Override with: ANSIBLE_GCP_LOG_LEVEL=DEBUG ansible-playbook main.yml
# ---------------------------------------------------------------------------
log = logging.getLogger("gcp_metrics")
logging.basicConfig(
    level=os.environ.get("ANSIBLE_GCP_LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

# ---------------------------------------------------------------------------
# Retry policy — exponential back-off for transient GCP API errors
# ---------------------------------------------------------------------------
_RETRY = api_retry.Retry(
    initial=1.0,
    maximum=30.0,
    multiplier=2.0,
    deadline=120.0,
    predicate=api_retry.if_transient_error,
)
API_TIMEOUT = 60  # seconds per individual API call


# ---------------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------------
def _resolve_sa_path(raw_path: str) -> str:
    """
    Resolve service_account value.
    Supports:
      - Literal file path:          /etc/ansible/GCP_Auth/gp-lab.json
      - Env-var reference:          ${GP_LAB_SA_KEY}
    """
    if raw_path and raw_path.startswith("${") and raw_path.endswith("}"):
        var_name = raw_path[2:-1]
        resolved = os.environ.get(var_name)
        if not resolved:
            raise EnvironmentError(
                f"Environment variable '{var_name}' is not set. "
                "Export it before running the playbook."
            )
        return resolved
    return raw_path


def get_credentials(project: dict):
    """
    Build scoped GCP credentials for a project.

    Priority:
      1. service_account field (literal path or ${ENV_VAR} reference)
      2. Application Default Credentials / Workload Identity (no field needed)

    Credentials are explicitly scoped to the minimum required permissions:
      - monitoring.read  — list time series
      - compute.readonly — list networks / VPC peering
    """
    _SCOPES = [
        "https://www.googleapis.com/auth/monitoring.read",
        "https://www.googleapis.com/auth/compute.readonly",
    ]

    raw = project.get("service_account")
    if raw:
        sa_path = _resolve_sa_path(raw)
        log.debug("Using SA key file for %s", project["project_id"])
        return service_account.Credentials.from_service_account_file(
            sa_path, scopes=_SCOPES
        )

    # Fall back to Application Default Credentials (Workload Identity etc.)
    import google.auth
    log.debug("Using ADC for %s", project["project_id"])
    creds, _ = google.auth.default(scopes=_SCOPES)
    return creds


# ---------------------------------------------------------------------------
# TIME WINDOW
# ---------------------------------------------------------------------------
def get_interval(window_seconds: int) -> dict:
    now = int(time.time())
    return {
        "end_time": {"seconds": now},
        "start_time": {"seconds": now - window_seconds},
    }


# ---------------------------------------------------------------------------
# RESOURCE NAME
# ---------------------------------------------------------------------------
def get_resource_name(labels: dict) -> str:
    """Return the most descriptive label from a resource label dict."""
    return (
        labels.get("router_id")
        or labels.get("instance_id")
        or labels.get("gateway_name")
        or labels.get("vpn_gateway_name")
        or labels.get("network_name")
        or labels.get("project_id")
        or "unknown"
    )


# ---------------------------------------------------------------------------
# FETCH METRIC
# ---------------------------------------------------------------------------
def fetch_metric(
    client: "monitoring_v3.MetricServiceClient",
    project_id: str,
    metric_type: str,
    window_seconds: int,
) -> list:
    """
    Fetch all time-series for one metric type over the given window.

    Returns a list of dicts:
      { resource, avg, max, latest, has_zero }

    has_zero is True when at least one data point was literally 0 —
    this allows evaluate() to correctly flag a down BGP session
    (session_up=0) even though zero is a valid data point.

    Returns [] on permanent errors (metric not found, permission denied).
    Retries automatically on transient errors (429, 503).
    """
    try:
        results = client.list_time_series(
            request={
                "name": f"projects/{project_id}",
                "filter": f'metric.type="{metric_type}"',
                "interval": get_interval(window_seconds),
                "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL,
            },
            retry=_RETRY,
            timeout=API_TIMEOUT,
        )

        resource_data = []

        for ts in results:
            labels = dict(ts.resource.labels)
            resource_name = get_resource_name(labels)

            values = []
            has_zero = False

            for p in ts.points:
                # KEY FIX: use explicit `is not None` so that a real value
                # of 0 (e.g. session_up=0 = BGP down) is never silently dropped.
                dv = p.value.double_value
                iv = p.value.int64_value

                if dv is not None and dv != 0.0:
                    values.append(dv)
                elif iv is not None and iv != 0:
                    values.append(iv)
                elif dv == 0.0 or iv == 0:
                    # Record that a zero was seen but don't add to values
                    # so avg/max calculations remain meaningful.
                    has_zero = True
                    values.append(0)

            if not values and not has_zero:
                continue

            safe_values = values if values else [0]
            resource_data.append({
                "resource": resource_name,
                "avg": sum(safe_values) / len(safe_values),
                "max": max(safe_values),
                "latest": safe_values[0],
                "has_zero": has_zero or (0 in values),
            })

        return resource_data

    except (GoogleAPICallError, RetryError) as e:
        msg = str(e).lower()
        if "not found" in msg or "cannot find metric" in msg:
            log.debug("%s | %s → metric not found, skipping", project_id, metric_type)
        else:
            log.error("API error %s | %s → %s", project_id, metric_type, e)
        return []
    except Exception as e:
        log.error("Unexpected error %s | %s → %s", project_id, metric_type, e)
        return []


# ---------------------------------------------------------------------------
# EVALUATE
# ---------------------------------------------------------------------------
def evaluate(resource_data: list, meta: dict) -> str:
    """
    Evaluate collected metric data against thresholds defined in metrics.yml.

    Returns:
      "GREEN"   — all resources within thresholds
      "RED"     — at least one resource breaches a threshold
      "NO_DATA" — no time-series returned (metric not configured / no data)

    meta keys:
      critical (bool)  — flag RED when value is 0 (e.g. BGP session down)
      threshold (num)  — numeric upper limit; values above this = RED
      unit (str)       — "mbps" converts bytes→Mbps before comparing;
                         "count" compares raw integer; default: "mbps"
      aggregation (str)— which aggregate to compare: avg | max | latest
    """
    if not resource_data:
        return "NO_DATA"

    agg = meta.get("aggregation", "avg")

    for item in resource_data:
        if agg == "avg":
            val = item["avg"]
        elif agg == "max":
            val = item["max"]
        else:
            val = item["latest"]

        # critical=true means val==0 is a failure (e.g. BGP session_up=0)
        # has_zero is set by fetch_metric when a literal 0 was seen in points.
        if meta.get("critical") and item.get("has_zero") and val == 0:
            return "RED"

        threshold = meta.get("threshold")
        unit = meta.get("unit", "mbps")

        if threshold is not None:
            compare_val = val / (1024 * 1024) if unit == "mbps" else val
            if compare_val > threshold:
                return "RED"

    return "GREEN"


# ---------------------------------------------------------------------------
# VPC PEERING
# ---------------------------------------------------------------------------
def get_vpc_peering(project_id: str, credentials) -> list:
    """
    Fetch VPC peering state via the Compute API.

    Returns a list of { resource, value } dicts where value is the
    peering state string (e.g. "ACTIVE", "INACTIVE").
    Returns [] on any error (logged explicitly).
    """
    try:
        svc = build("compute", "v1", credentials=credentials)
        networks = (
            svc.networks()
            .list(project=project_id)
            .execute(num_retries=3)
        )

        peerings = []
        for net in networks.get("items", []):
            for peer in net.get("peerings", []):
                peerings.append({
                    "resource": str(peer.get("name", "unknown")),
                    "value": str(peer.get("state", "UNKNOWN")),
                })

        return peerings

    except HttpError as e:
        log.error(
            "Compute API HTTP %s for %s VPC peering: %s",
            e.status_code, project_id, e,
        )
        return []
    except Exception as e:
        log.error("Unexpected error fetching VPC peering for %s: %s", project_id, e)
        return []


# ---------------------------------------------------------------------------
# PROCESS ONE PROJECT
# ---------------------------------------------------------------------------
def _pick_val(item: dict, agg: str) -> float:
    if agg == "avg":
        return item["avg"]
    elif agg == "max":
        return item["max"]
    return item["latest"]


def process_project(project: dict, metrics: dict, windows: dict) -> dict:
    """
    Collect all configured metrics + VPC peering for a single project
    across all time windows. Returns a structured result dict.
    """
    project_id = project["project_id"]
    log.info("Processing project: %s", project_id)

    try:
        credentials = get_credentials(project)
    except Exception as e:
        log.error("Credential error for %s: %s", project_id, e)
        return {
            "project_id": project_id,
            "error": str(e),
            "metrics": {},
        }

    monitoring = monitoring_v3.MetricServiceClient(credentials=credentials)

    result = {"project_id": project_id, "metrics": {}}

    # ---- Standard metrics ----
    for category, mset in metrics.items():
        result["metrics"][category] = {}

        for name, meta in mset.items():
            result["metrics"][category][name] = {}
            agg = meta.get("aggregation", "avg")

            for label, window_seconds in windows.items():
                resource_data = fetch_metric(
                    monitoring, project_id, meta["type"], window_seconds
                )
                status = evaluate(resource_data, meta)

                formatted = [
                    {"resource": item["resource"], "value": _pick_val(item, agg)}
                    for item in resource_data
                ]

                result["metrics"][category][name][label] = {
                    "value": formatted if formatted else None,
                    "status": status,
                }

    # ---- VPC peering (Compute API, not Cloud Monitoring) ----
    vpc_data = get_vpc_peering(project_id, credentials)
    result["metrics"]["vpc_peering"] = {}

    for label in windows:
        if not vpc_data:
            result["metrics"]["vpc_peering"][label] = {
                "value": None,
                "status": "NO_DATA",
            }
        else:
            vpc_status = (
                "GREEN"
                if all(p["value"] == "ACTIVE" for p in vpc_data)
                else "RED"
            )
            result["metrics"]["vpc_peering"][label] = {
                "value": vpc_data,
                "status": vpc_status,
            }

    return result


# ---------------------------------------------------------------------------
# ANSIBLE MODULE ENTRY POINT
# ---------------------------------------------------------------------------
def run_module():
    module = AnsibleModule(
        argument_spec=dict(
            projects=dict(type="list",  required=True),
            metrics= dict(type="dict",  required=True),
            windows= dict(type="dict",  required=True),
        ),
        supports_check_mode=True,
    )

    if not HAS_GOOGLE_LIBS:
        module.fail_json(
            msg=f"Required Google libraries not found: {GOOGLE_IMPORT_ERROR}. "
                "Run: pip install google-cloud-monitoring google-auth "
                "google-api-python-client google-api-core"
        )

    if module.check_mode:
        module.exit_json(changed=False, msg="Check mode: no API calls made.")

    projects = module.params["projects"]
    metrics  = module.params["metrics"]
    windows  = module.params["windows"]

    max_workers = min(len(projects), int(os.environ.get("GCP_MONITOR_WORKERS", "5")))
    results = [None] * len(projects)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(process_project, p, metrics, windows): i
            for i, p in enumerate(projects)
        }
        for future in as_completed(future_map):
            idx = future_map[future]
            try:
                results[idx] = future.result()
            except Exception as e:
                pid = projects[idx].get("project_id", f"index-{idx}")
                log.error("Unhandled exception for %s: %s", pid, e)
                results[idx] = {
                    "project_id": pid,
                    "error": str(e),
                    "metrics": {},
                }

    module.exit_json(changed=False, data=results)


def main():
    run_module()


if __name__ == "__main__":
    main()
