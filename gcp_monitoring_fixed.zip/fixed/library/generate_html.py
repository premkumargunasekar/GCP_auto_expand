#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
generate_html.py — Convert report.json into a self-contained HTML dashboard.

Usage (called by main.yml):
    python3 library/generate_html.py output/report.json output/report.html

All dynamic values are HTML-escaped before insertion to prevent XSS.
File I/O is wrapped in context managers.
The script is structured as a callable main() function so it can be tested
and imported without executing at import time.
"""

import json
import sys
import logging
from html import escape
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("generate_html")
logging.basicConfig(
    level="INFO",
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

# ---------------------------------------------------------------------------
# Status helpers
# ---------------------------------------------------------------------------
_STATUS_MAP = {
    "GREEN":   ("ok",   "OK"),
    "RED":     ("crit", "CRITICAL"),
    "NO_DATA": ("na",   "NO DATA"),
}


def status_class(status: str) -> tuple:
    return _STATUS_MAP.get(status, ("na", "NO DATA"))


def clean_value(val) -> str:
    """Format a metric value for display. Rounds floats; falls back to '-'."""
    if val is None:
        return "-"
    if isinstance(val, float):
        return str(round(val, 2))
    return escape(str(val))


# ---------------------------------------------------------------------------
# HTML builder
# ---------------------------------------------------------------------------
CSS = """
body{font-family:Segoe UI,sans-serif;background:#f4f6f9;margin:20px}
h1{text-align:center}
h2{margin-top:30px}
h3{margin:0 0 12px}
.tabs{text-align:center;margin-bottom:20px}
button{padding:8px 16px;margin:5px;border:none;cursor:pointer;border-radius:6px;font-size:14px;background:#e5e7eb}
button.active{background:#2563eb;color:#fff}
.section{display:none}
.project{margin-bottom:40px}
.card{background:#fff;padding:15px;margin-bottom:20px;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.1)}
.error-banner{background:#fee2e2;border:1px solid #fca5a5;border-radius:6px;
  padding:10px 14px;color:#991b1b;font-size:13px;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{background:#111827;color:#fff;padding:10px;text-align:left}
th:nth-child(3),th:nth-child(4){text-align:center}
td{padding:10px;border-bottom:1px solid #eee}
td:nth-child(3),td:nth-child(4){text-align:center}
.ok{color:green;font-weight:bold}
.crit{color:red;font-weight:bold}
.na{color:gray;font-weight:bold}
"""

JS = """
function show(tab){
  document.querySelectorAll('.section').forEach(e=>e.style.display='none');
  document.querySelectorAll('.'+tab).forEach(e=>e.style.display='block');
  document.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
  document.getElementById(tab).classList.add('active');
}
setTimeout(()=>location.reload(),5*60*1000);
"""


def build_metric_rows(metric: str, win_entry: dict) -> str:
    """Build one or more <tr> rows for a single metric + window combination."""
    status  = win_entry.get("status", "NO_DATA")
    values  = win_entry.get("value")
    css, label = status_class(status)
    safe_metric = escape(metric)
    safe_label  = escape(label)

    if not values:
        return (
            f"<tr><td>{safe_metric}</td><td>-</td>"
            f"<td>-</td><td class='{css}'>{safe_label}</td></tr>\n"
        )

    rows = ""
    seen = {}
    for item in values:
        resource = str(item.get("resource", "unknown"))
        seen[resource] = item.get("value")

    for resource, val in seen.items():
        rows += (
            f"<tr>"
            f"<td>{safe_metric}</td>"
            f"<td>{escape(resource)}</td>"
            f"<td>{clean_value(val)}</td>"
            f"<td class='{css}'>{safe_label}</td>"
            f"</tr>\n"
        )
    return rows


def build_dashboard(data: list, generated_at: str) -> str:
    parts = [
        "<!DOCTYPE html>\n<html lang='en'>\n<head>\n",
        "<meta charset='UTF-8'>\n",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>\n",
        "<meta http-equiv='refresh' content='300'>\n",
        "<title>GCP Monitoring Dashboard</title>\n",
        f"<style>{CSS}</style>\n",
        f"<script>{JS}</script>\n",
        "</head>\n<body>\n",
        "<h1>GCP Monitoring Dashboard</h1>\n",
        f"<p style='text-align:center'>Generated: {escape(generated_at)}</p>\n",
        "<div class='tabs'>\n",
        "<button id='D1' class='active' onclick=\"show('D1')\">1 Day</button>\n",
        "<button id='D3' onclick=\"show('D3')\">3 Days</button>\n",
        "<button id='D7' onclick=\"show('D7')\">7 Days</button>\n",
        "</div>\n",
    ]

    for window in ["D1", "D3", "D7"]:
        parts.append(f"<div class='section {window}'>\n")

        for project in data:
            project_id = str(project.get("project_id", "unknown"))
            parts.append(f"<div class='project'>\n")
            parts.append(
                f"<h2>Project: {escape(project_id)} ({escape(window)})</h2>\n"
            )

            # Surface any top-level collection error for this project
            if "error" in project:
                parts.append(
                    f"<div class='error-banner'>Collection error: "
                    f"{escape(str(project['error']))}</div>\n"
                )

            for comp, metrics in project.get("metrics", {}).items():
                safe_comp = escape(comp.replace("_", " ").title())
                parts.append(f"<div class='card'><h3>{safe_comp}</h3>\n")
                parts.append(
                    "<table>\n<tr>"
                    "<th>Metric</th><th>Resource</th>"
                    "<th>Value</th><th>Status</th>"
                    "</tr>\n"
                )

                has_rows = False

                # vpc_peering is stored flat (no per-metric nesting)
                if comp == "vpc_peering":
                    entry = metrics.get(window)
                    if entry:
                        has_rows = True
                        parts.append(
                            build_metric_rows("vpc_peering", entry)
                        )
                else:
                    for metric_name, win_data in metrics.items():
                        if window not in win_data:
                            continue
                        has_rows = True
                        parts.append(
                            build_metric_rows(metric_name, win_data[window])
                        )

                if not has_rows:
                    parts.append(
                        "<tr><td colspan='4' class='na' style='text-align:center'>"
                        "No data for this window</td></tr>\n"
                    )

                parts.append("</table></div>\n")

            parts.append("</div>\n")  # /project

        parts.append("</div>\n")  # /section

    parts.append("<script>show('D1');</script>\n</body>\n</html>\n")
    return "".join(parts)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_input(data) -> None:
    if not isinstance(data, list):
        raise ValueError(
            f"report.json must contain a JSON array at the top level, "
            f"got {type(data).__name__}"
        )
    for i, entry in enumerate(data):
        if not isinstance(entry, dict):
            raise ValueError(f"Item {i} in report.json is not a dict")
        if "project_id" not in entry:
            raise ValueError(f"Item {i} in report.json has no 'project_id' key")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main(input_path: str, output_path: str) -> None:
    input_file  = Path(input_path)
    output_file = Path(output_path)

    if not input_file.exists():
        log.error("Input file not found: %s", input_file)
        sys.exit(1)

    with open(input_file, encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as e:
            log.error("Failed to parse %s: %s", input_file, e)
            sys.exit(1)

    try:
        validate_input(data)
    except ValueError as e:
        log.error("Input validation failed: %s", e)
        sys.exit(1)

    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    html = build_dashboard(data, generated_at)

    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    log.info("Dashboard written to %s (%d bytes)", output_file, len(html))
    print(f"HTML generated: {output_file}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.json> <output.html>", file=sys.stderr)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
