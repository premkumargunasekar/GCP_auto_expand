# GCP SOP Monitoring

Ansible-based GCP network monitoring tool. Collects Cloud Monitoring
metrics and VPC peering state across multiple projects, outputs a JSON
report and a self-contained HTML dashboard.

---

## Structure

```
.
├── main.yml                         # Ansible playbook entry point
├── library/
│   ├── gcp_metrics.py               # Ansible module — collects metrics
│   └── generate_html.py             # Converts report.json → dashboard HTML
├── group_vars/all/
│   ├── projects.yml                 # Projects + credentials config
│   └── metrics.yml                  # Metrics, thresholds, time windows
└── output/                          # Created at runtime
    ├── report.json
    └── report.html
```

---

## Requirements

```
pip install \
  ansible \
  google-cloud-monitoring \
  google-auth \
  google-api-python-client \
  google-api-core
```

Python 3.8+ required.

---

## Authentication

Three options, in priority order:

**1. Env-var reference (recommended)**
```bash
export GP_LAB_SA_KEY=/etc/ansible/GCP_Auth/gp-lab.json
export GP_DEV_SA_KEY=/etc/ansible/GCP_Auth/gp-dev.json
ansible-playbook main.yml
```
projects.yml uses `${GP_LAB_SA_KEY}` — the module resolves it at runtime.

**2. Literal path (dev/local only)**
Set `service_account: /path/to/key.json` directly in projects.yml.
Do not commit key paths or key files to version control.

**3. Workload Identity / ADC (production GCE/GKE)**
Omit `service_account` entirely. The module falls back to
`google.auth.default()` which picks up the instance service account
or `GOOGLE_APPLICATION_CREDENTIALS`.

**Required IAM roles per project:**
- `roles/monitoring.viewer`  — Cloud Monitoring read
- `roles/compute.networkViewer` — VPC peering read

---

## Usage

```bash
# Standard run
ansible-playbook main.yml

# Verbose logging from the module
ANSIBLE_GCP_LOG_LEVEL=DEBUG ansible-playbook main.yml

# Control parallelism (default: 5 threads)
GCP_MONITOR_WORKERS=10 ansible-playbook main.yml
```

Outputs are written to `./output/report.json` and `./output/report.html`.

---

## Adding a new metric

1. Add an entry under the appropriate category in `group_vars/all/metrics.yml`:
   ```yaml
   my_category:
     my_metric_name:
       type: <full GCP metric type string>
       aggregation: avg   # avg | max | latest
       unit: mbps         # mbps | count
       threshold: 200     # RED above this value
   ```

2. Run the playbook. No code changes needed.

---

## Adding a new project

Add an entry to `group_vars/all/projects.yml`:
```yaml
- project_id: my-new-project
  env: prod
  service_account: "${MY_NEW_PROJECT_SA_KEY}"
```
Export the env var and run the playbook.

---

## Known fixes vs original

| Issue | Fix |
|---|---|
| Zero-value metrics silently dropped (`if p.value.double_value`) | Changed to explicit `is not None` check; `has_zero` flag passed to `evaluate()` |
| BGP session=0 (DOWN) never flagged RED | `evaluate()` now checks `has_zero` before `critical` comparison |
| Bare `except: return []` hid all errors | Separate `GoogleAPICallError`, `HttpError`, `Exception` handlers with logging |
| No structured logging | `logging` module throughout; level via `ANSIBLE_GCP_LOG_LEVEL` env var |
| SA key paths hardcoded in projects.yml | `${ENV_VAR}` references resolved at runtime; ADC fallback added |
| No credential scoping | Credentials explicitly scoped to `monitoring.read` + `compute.readonly` |
| No retry on transient GCP errors | `google.api_core.retry.Retry` with exponential back-off on all API calls |
| No API call timeouts | 60-second timeout on `list_time_series`; `num_retries=3` on Compute calls |
| XSS in HTML generation | `html.escape()` on every dynamic value in `generate_html.py` |
| File I/O outside `main()` in generate_html.py | Moved into `main()` function; script safe to import |
| `datetime.utcnow()` deprecated (Python 3.12+) | Replaced with `datetime.now(timezone.utc)` |
| No input validation in generate_html.py | `validate_input()` checks structure before rendering |
| `allocated_ports` flagged CRITICAL for any value > 0 | Fixed in metrics.yml with a gauge-style threshold (not `threshold: 0`) |
| Parallel futures inserted in completion order → inconsistent JSON key order | `results` list pre-allocated by index; order preserved |
| No `supports_check_mode` in Ansible module | Added; `--check` runs without making any API calls |
| No dependency check for Google libraries | `HAS_GOOGLE_LIBS` guard with `module.fail_json()` if missing |
