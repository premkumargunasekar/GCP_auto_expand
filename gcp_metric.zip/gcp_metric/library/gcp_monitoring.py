#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
from google.cloud import monitoring_v3
from google.oauth2 import service_account
from google.protobuf.timestamp_pb2 import Timestamp
from datetime import datetime, timezone


def to_timestamp(timestr):
    dt = datetime.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    ts = Timestamp()
    ts.FromDatetime(dt)
    return ts


def run_module():
    module = AnsibleModule(
        argument_spec=dict(
            project_id=dict(type='str', required=True),
            start_time=dict(type='str', required=True),
            end_time=dict(type='str', required=True),
            metrics=dict(type='dict', required=True),
            service_account=dict(type='str', required=True),
        )
    )

    try:
        # FIX: Add scope
        creds = service_account.Credentials.from_service_account_file(
            module.params['service_account'],
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )

        client = monitoring_v3.MetricServiceClient(credentials=creds)

        project = f"projects/{module.params['project_id']}"

        interval = monitoring_v3.TimeInterval(
            start_time=to_timestamp(module.params['start_time']),
            end_time=to_timestamp(module.params['end_time'])
        )

        #  FIX: Proper aggregation object
        aggregation = monitoring_v3.Aggregation(
            alignment_period={"seconds": 3600},
            per_series_aligner=monitoring_v3.Aggregation.Aligner.ALIGN_SUM
        )

        output = {}

        for category, metric_list in module.params['metrics'].items():
            output[category] = []

            for metric in metric_list:
                total = 0
                count = 0
                max_points = 100000  # safety guard

                try:
                    module.warn(f"Processing metric: {metric}")

                    results = client.list_time_series(
                        request={
                            "name": project,
                            "filter": f'metric.type="{metric}"',
                            "interval": interval,
                            "aggregation": aggregation
                        },
                        timeout=30
                    )

                    for ts in results:
                        for p in ts.points:
                            count += 1
                            if count > max_points:
                                module.warn(f"Max points reached for {metric}, truncating...")
                                break

                            kind = p.value.WhichOneof("value")

                            if kind == "double_value":
                                total += p.value.double_value
                            elif kind == "int64_value":
                                total += p.value.int64_value
                            elif kind == "bool_value":
                                total += int(p.value.bool_value)

                        if count > max_points:
                            break

                    value = "0" if total == 0 else str(int(total))

                    output[category].append({
                        "metric": metric,
                        "value": value
                    })

                except Exception as e:
                    output[category].append({
                        "metric": metric,
                        "value": "ERROR",
                        "error": f"{type(e).__name__}: {str(e)}"
                    })

        module.exit_json(changed=False, data=output)

    except Exception as e:
        module.fail_json(msg=f"{type(e).__name__}: {str(e)}")


if __name__ == '__main__':
    run_module()