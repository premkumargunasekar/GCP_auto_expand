#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
from google.cloud import monitoring_v3
from google.oauth2 import service_account
from google.protobuf.timestamp_pb2 import Timestamp
from datetime import datetime

def to_timestamp(timestr):
    dt = datetime.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    ts = Timestamp()
    ts.FromDatetime(dt)
    return ts

def run_module():
    module = AnsibleModule(
        argument_spec=dict(
            project_id=dict(type='str', required=True),
            start_time=dict(type='str', required=True),
            end_time=dict(type='str', required=True),
            metrics=dict(type='dict', required=True),
            service_account=dict(type='str', required=True),
        )
    )

    try:
        creds = service_account.Credentials.from_service_account_file(
            module.params['service_account']
        )

        client = monitoring_v3.MetricServiceClient(credentials=creds)

        project = f"projects/{module.params['project_id']}"

        interval = monitoring_v3.TimeInterval(
            start_time=to_timestamp(module.params['start_time']),
            end_time=to_timestamp(module.params['end_time'])
        )

        output = {}

        for category, metric_list in module.params['metrics'].items():
            output[category] = []

            for metric in metric_list:
                total = 0
                try:
                    results = client.list_time_series(
                        request={
                            "name": project,
                            "filter": f'metric.type="{metric}"',
                            "interval": interval,
                        }
                    )

                    for ts in results:
                        for p in ts.points:
                            if hasattr(p.value, "double_value"):
                                total += p.value.double_value
                            elif hasattr(p.value, "int64_value"):
                                total += p.value.int64_value

                    output[category].append({
                        "metric": metric,
                        "value": str(int(total))
                    })

                except Exception as e:
                    output[category].append({
                        "metric": metric,
                        "value": "ERROR",
                        "error": str(e)
                    })

        module.exit_json(changed=False, data=output)

    except Exception as e:
        module.fail_json(msg=str(e))

if __name__ == '__main__':
    run_module()
