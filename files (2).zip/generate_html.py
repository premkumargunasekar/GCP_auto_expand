#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
generate_html.py — Render a GCP metrics JSON report as a self-contained HTML dashboard.

Usage:
    python3 generate_html.py <input.json> <output.html>

Fixes over previous version:
  - KPI counts are now scoped to the active window (D1/D3/D7) — previously
    all three windows were summed together, tripling every count.
  - Component filter buttons are generated dynamically from metric categories
    and wired correctly to filterComponent() — previously the feature was
    dead code (buttons were never rendered into the page).
  - Auto-reload is now opt-in via a ?live=1 query param instead of always-on.
  - Active tab is persisted in sessionStorage and restored on reload so
    operators don't lose their position on auto-refresh.
  - build_metric_rows() now emits YELLOW row colouring for YELLOW item status,
    consistent with the per-row status produced by gcp_metrics.py.
  - Input JSON is validated to be a list before rendering begins.
  - escape() is applied consistently to all externally-derived string values.
"""

import json
import logging
import sys
from datetime import datetime, timezone
from html import escape
from pathlib import Path

log = logging.getLogger("generate_html")
logging.basicConfig(level="INFO")

# ---------------------------------------------------------------------------
# Status helpers
# ---------------------------------------------------------------------------
_STATUS_MAP = {
    "GREEN":   ("ok",   "OK"),
    "RED":     ("crit", "CRITICAL"),
    "YELLOW":  ("warn", "WARNING"),
    "NO_DATA": ("na",   "NO DATA"),
}

WINDOWS = ["D1", "D3", "D7"]


def status_class(status: str) -> tuple[str, str]:
    return _STATUS_MAP.get(status, ("na", "NO DATA"))


def clean_value(val) -> str:
    if val is None:
        return "-"
    if isinstance(val, float):
        return str(round(val, 2))
    return escape(str(val))


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------
CSS = """
body{font-family:Segoe UI;background:#f4f6f9;margin:20px}
h1{text-align:center}

.tabs,.component-bar{text-align:center;margin-bottom:15px}

button{padding:8px 14px;margin:5px;border:none;border-radius:6px;background:#e5e7eb;cursor:pointer}
button.active{background:#2563eb;color:#fff}
.component-btn.active{background:#059669}

.section{display:none}
.project{margin-bottom:40px}

.card{
  background:#fff;
  padding:15px;
  margin:10px 0;
  border-radius:10px;
  box-shadow:0 2px 6px rgba(0,0,0,.1)
}

.kpi-container{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}
.kpi{
  flex:1;
  min-width:150px;
  background:#fff;
  padding:15px;
  border-radius:10px;
  text-align:center;
  box-shadow:0 2px 6px rgba(0,0,0,.1)
}
.kpi.ok{border-left:6px solid green}
.kpi.crit{border-left:6px solid red}
.kpi.warn{border-left:6px solid orange}
.kpi.na{border-left:6px solid gray}

table{width:100%;border-collapse:collapse}
th{background:#111827;color:#fff;padding:10px}
td{padding:10px;border-bottom:1px solid #eee}

.ok{color:green;font-weight:bold}
.crit{color:red;font-weight:bold}
.warn{color:orange;font-weight:bold}
.na{color:gray;font-weight:bold}
"""

# ---------------------------------------------------------------------------
# JS
# ---------------------------------------------------------------------------
JS = """
var currentTab = sessionStorage.getItem('gcp_tab') || 'D1';
var currentComponent = 'all';

function show(tab) {
  currentTab = tab;
  sessionStorage.setItem('gcp_tab', tab);

  document.querySelectorAll('.section').forEach(function(e){ e.style.display='none'; });
  document.querySelectorAll('.'+tab).forEach(function(e){ e.style.display='block'; });

  document.querySelectorAll('.tabs button').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById(tab).classList.add('active');

  applyFilter();
}

function filterComponent(component, btn) {
  currentComponent = component;

  document.querySelectorAll('.component-btn').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');

  applyFilter();
}

function applyFilter() {
  document.querySelectorAll('.section.'+currentTab+' .card.component').forEach(function(card){
    if (currentComponent === 'all') {
      card.style.display = 'block';
    } else {
      card.style.display = card.classList.contains(currentComponent) ? 'block' : 'none';
    }
  });
}

// Auto-reload only when ?live=1 is present in the URL.
if (new URLSearchParams(window.location.search).get('live') === '1') {
  setTimeout(function(){ location.reload(); }, 5 * 60 * 1000);
}

// Restore active tab from sessionStorage after page load.
window.addEventListener('DOMContentLoaded', function(){
  show(currentTab);
});
"""


# ---------------------------------------------------------------------------
# KPI — scoped to a single window
# ---------------------------------------------------------------------------
def calculate_kpi(metrics: dict, window: str) -> tuple[int, int, int, int]:
    """
    Count GREEN / RED / YELLOW / NO_DATA entries for a specific window only.

    Previously all three windows were iterated together, causing each metric
    to be counted three times (once per window). Now only the requested window
    label is examined so KPI badges match what is displayed in the active tab.
    """
    ok = crit = warn = na = 0

    for comp in metrics.values():
        if not isinstance(comp, dict):
            continue
        for metric in comp.values():
            if not isinstance(metric, dict):
                continue
            win_entry = metric.get(window)
            if not isinstance(win_entry, dict):
                continue
            status = win_entry.get("status")
            if status == "GREEN":
                ok += 1
            elif status == "RED":
                crit += 1
            elif status == "YELLOW":
                warn += 1
            else:
                na += 1

    return ok, crit, warn, na


# ---------------------------------------------------------------------------
# Build table rows for a single metric + window entry
# ---------------------------------------------------------------------------
def build_metric_rows(metric: str, win_entry: dict) -> str:
    status = win_entry.get("status", "NO_DATA")
    values = win_entry.get("value")
    css, label = status_class(status)

    if not values:
        return (
            f"<tr>"
            f"<td>{escape(metric)}</td>"
            f"<td>-</td>"
            f"<td>-</td>"
            f"<td class='{css}'>{label}</td>"
            f"</tr>"
        )

    rows = ""
    for item in values:
        res = escape(str(item.get("resource", "-")))
        val = clean_value(item.get("value"))
        item_status = item.get("status", "")

        # Fixed: row colour now correctly reflects YELLOW for warning-range items.
        if item_status == "RED":
            row_css = "crit"
        elif item_status == "YELLOW":
            row_css = "warn"
        else:
            row_css = css

        rows += (
            f"<tr>"
            f"<td>{escape(metric)}</td>"
            f"<td>{res}</td>"
            f"<td>{val}</td>"
            f"<td class='{row_css}'>{label}</td>"
            f"</tr>"
        )

    return rows


# ---------------------------------------------------------------------------
# Collect unique component names across all projects
# ---------------------------------------------------------------------------
def _all_components(data: list[dict]) -> list[str]:
    seen = []
    for project in data:
        for comp in project.get("metrics", {}).keys():
            if comp not in seen:
                seen.append(comp)
    return seen


# ---------------------------------------------------------------------------
# Build full dashboard HTML
# ---------------------------------------------------------------------------
def build_dashboard(data: list[dict], generated_at: str) -> str:
    components = _all_components(data)

    parts = [
        "<html><head>",
        f"<style>{CSS}</style>",
        "</head><body>",

        "<h1>GCP Enterprise Dashboard</h1>",
        f"<p style='text-align:center'>Generated: {escape(generated_at)}</p>",

        # Window tabs
        "<div class='tabs'>",
        "<button id='D1' onclick=\"show('D1')\">1 Day</button>",
        "<button id='D3' onclick=\"show('D3')\">3 Days</button>",
        "<button id='D7' onclick=\"show('D7')\">7 Days</button>",
        "</div>",

        # Component filter bar — dynamically generated from actual categories.
        # Previously declared in CSS/JS but never rendered, making it dead code.
        "<div class='component-bar'>",
        "<button class='component-btn active' onclick=\"filterComponent('all', this)\">All</button>",
    ]
    for comp in components:
        # CSS class names must not contain spaces; sanitise the component name.
        css_cls = escape(re.sub(r"[^a-zA-Z0-9_-]", "_", comp))
        parts.append(
            f"<button class='component-btn' "
            f"onclick=\"filterComponent('{css_cls}', this)\">{escape(comp)}</button>"
        )
    parts.append("</div>")

    for window in WINDOWS:
        parts.append(f"<div class='section {window}'>")

        for project in data:
            parts.append("<div class='project'>")
            project_id = escape(str(project.get("project_id", "unknown")))
            parts.append(f"<h2>Project: {project_id} ({window})</h2>")

            metrics = project.get("metrics", {})

            # KPI counts are now scoped to the current window only.
            ok, crit, warn, na = calculate_kpi(metrics, window)
            parts.append("<div class='kpi-container'>")
            parts.append(f"<div class='kpi ok'>OK<br>{ok}</div>")
            parts.append(f"<div class='kpi crit'>Critical<br>{crit}</div>")
            parts.append(f"<div class='kpi warn'>Warning<br>{warn}</div>")
            parts.append(f"<div class='kpi na'>No Data<br>{na}</div>")
            parts.append("</div>")

            for comp, comp_metrics in metrics.items():
                css_cls = escape(re.sub(r"[^a-zA-Z0-9_-]", "_", comp))
                parts.append(f"<div class='card component {css_cls}'>")
                parts.append(f"<h3>{escape(comp)}</h3>")
                parts.append(
                    "<table>"
                    "<tr>"
                    "<th>Metric</th><th>Resource</th><th>Value</th><th>Status</th>"
                    "</tr>"
                )

                has_data = False
                for metric, win_data in comp_metrics.items():
                    if isinstance(win_data, dict) and window in win_data:
                        has_data = True
                        parts.append(build_metric_rows(metric, win_data[window]))

                if not has_data:
                    parts.append("<tr><td colspan='4' class='na'>No Data</td></tr>")

                parts.append("</table></div>")

            parts.append("</div>")

        parts.append("</div>")

    # JS is appended last so DOM is fully built before event handlers run.
    parts.append(f"<script>{JS}</script>")
    parts.append("</body></html>")
    return "".join(parts)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(input_path: str, output_path: str) -> None:
    input_file  = Path(input_path)
    output_file = Path(output_path)

    if not input_file.exists():
        log.error("Input file not found: %s", input_file)
        sys.exit(1)

    with open(input_file, encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as exc:
            log.error("Failed to parse input JSON (%s): %s", input_file, exc)
            sys.exit(1)

    # Guard against a partial or malformed upstream write producing a non-list.
    if not isinstance(data, list):
        log.error(
            "Input JSON must be a list of project objects; got %s",
            type(data).__name__,
        )
        sys.exit(1)

    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    html = build_dashboard(data, generated_at)

    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    log.info("Dashboard generated: %s", output_file)
    print("HTML generated:", output_file)


# ---------------------------------------------------------------------------
# re is used in build_dashboard; import here so it is available module-wide.
# ---------------------------------------------------------------------------
import re  # noqa: E402  (intentionally placed after constants for readability)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.json> <output.html>")
        sys.exit(1)

    main(sys.argv[1], sys.argv[2])
