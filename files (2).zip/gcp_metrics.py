#!/usr/bin/env python3
"""
gcp_metrics.py — Fetch GCP Cloud Monitoring metrics for all projects and windows.

Usage (called by main.yml via Ansible):
    python3 library/gcp_metrics.py

Fixes over previous version:
  - Zero-value bug: uses HasField() to safely detect int64/double values
  - critical: true support: session_up=0 → RED
  - warning threshold: returns YELLOW between warning and critical threshold
  - _format_resource() now correctly emits YELLOW for warning-range values
  - _validate_metrics() is now called inside process_project()
  - Unknown unit values are logged as warnings instead of silently passing through
  - Credential errors are split by type for actionable error messages
  - has_zero field removed (was computed but never used)
  - API calls now include a configurable timeout
  - API sort order assumption is documented with an explicit comment
  - Env-var credential references: supports ${MY_ENV_VAR} in projects.yml
  - Per-project error isolation: one project failure won't crash the run
  - Application Default Credentials (ADC) fallback when no service_account
  - Input validation on project and metrics config
  - Structured logging with timestamps
"""

import logging
import os
import re
import sys
from datetime import datetime, timedelta, timezone

import google.auth
import google.auth.exceptions
from google.api_core.exceptions import GoogleAPICallError
from google.cloud import monitoring_v3
from google.oauth2 import service_account

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=os.environ.get("ANSIBLE_GCP_LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("gcp_metrics")

# Default timeout for all GCP API calls (seconds). Override via env var.
API_TIMEOUT = float(os.environ.get("ANSIBLE_GCP_API_TIMEOUT", "30.0"))

# Known unit values and their conversion logic.
_KNOWN_UNITS = {"mbps", "kbps", "count"}

# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------
_ENV_VAR_RE = re.compile(r"^\$\{([^}]+)\}$")


def _resolve_credential_path(raw: str) -> str:
    """
    Resolve a service_account value that may be a literal path or an
    env-var reference like ${GP_LAB_SA_KEY}.

    Raises ValueError if the env var is declared but not set.
    """
    m = _ENV_VAR_RE.match(raw.strip())
    if m:
        var_name = m.group(1)
        value = os.environ.get(var_name)
        if not value:
            raise ValueError(
                f"Environment variable '{var_name}' is not set. "
                f"Export it before running the playbook."
            )
        return value
    return raw


def build_client(project: dict) -> monitoring_v3.MetricServiceClient:
    """
    Build a MetricServiceClient for the given project config.

    Priority:
      1. service_account key (literal path or ${ENV_VAR})
      2. Application Default Credentials (GCE / Workload Identity / gcloud auth)

    Raises distinct exceptions per failure mode so callers can log them
    with appropriate severity and actionable messages.
    """
    raw = project.get("service_account", "").strip()
    if raw:
        path = _resolve_credential_path(raw)
        try:
            creds = service_account.Credentials.from_service_account_file(
                path,
                scopes=["https://www.googleapis.com/auth/monitoring.read"],
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Service account key file not found: {path}"
            )
        except ValueError as exc:
            raise ValueError(
                f"Service account key file is malformed ({path}): {exc}"
            )
        log.debug("Project %s: using service account %s", project["project_id"], path)
    else:
        try:
            creds, _ = google.auth.default(
                scopes=["https://www.googleapis.com/auth/monitoring.read"]
            )
        except google.auth.exceptions.DefaultCredentialsError as exc:
            raise google.auth.exceptions.DefaultCredentialsError(
                f"Application Default Credentials not available: {exc}"
            )
        log.debug(
            "Project %s: using Application Default Credentials",
            project["project_id"],
        )

    return monitoring_v3.MetricServiceClient(credentials=creds)


# ---------------------------------------------------------------------------
# Resource label → human-readable name
# ---------------------------------------------------------------------------
_LABEL_PRIORITY = [
    "attachment_name",
    "interconnect_attachment",
    "link_id",
    "router_id",
    "instance_id",
    "gateway_name",
    "vpn_gateway_name",
    "network_name",
    "project_id",
]


def get_resource_name(labels: dict) -> str:
    for key in _LABEL_PRIORITY:
        val = labels.get(key)
        if val:
            return val
    return "unknown"


# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------
def fetch_metric(
    client: monitoring_v3.MetricServiceClient,
    project_id: str,
    metric_type: str,
    window_seconds: int,
) -> list[dict]:
    """
    Fetch all time-series for metric_type over the last window_seconds.

    Returns a list of dicts:
        {resource, avg, max, latest}

    The GCP Monitoring API returns points in descending time order (newest
    first), so values[0] is always the most recent sample. This is documented
    behaviour for ListTimeSeries with FULL view; if the API contract changes,
    the 'latest' key will need to be re-derived from point timestamps.

    Raises GoogleAPICallError on API failure (caller handles it).
    """
    now = datetime.now(timezone.utc)
    start_time = now - timedelta(seconds=window_seconds)

    interval = monitoring_v3.TimeInterval(
        {"end_time": now, "start_time": start_time}
    )
    request = monitoring_v3.ListTimeSeriesRequest(
        name=f"projects/{project_id}",
        filter=f'metric.type="{metric_type}"',
        interval=interval,
        view=monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL,
    )

    results = client.list_time_series(request=request, timeout=API_TIMEOUT)
    resource_data = []

    for ts in results:
        labels = dict(ts.resource.labels)
        resource_name = get_resource_name(labels)
        values = []

        for p in ts.points:
            # Use HasField to safely detect zero values (0.0 / 0 are falsy)
            if p.value.HasField("double_value"):
                values.append(p.value.double_value)
            elif p.value.HasField("int64_value"):
                values.append(float(p.value.int64_value))

        if not values:
            continue

        resource_data.append({
            "resource": resource_name,
            "avg":      sum(values) / len(values),
            "max":      max(values),
            "latest":   values[0],  # newest point — see docstring above
        })

    return resource_data


# ---------------------------------------------------------------------------
# Value picker
# ---------------------------------------------------------------------------
def _pick_val(item: dict, agg: str) -> float:
    if agg == "avg":
        return item["avg"]
    if agg == "max":
        return item["max"]
    return item["latest"]


# ---------------------------------------------------------------------------
# Unit conversion
# ---------------------------------------------------------------------------
def _convert(raw_val: float, unit: str, metric_name: str = "") -> float:
    """
    Convert raw bytes-per-second values to the requested unit.

    Logs a warning for any unit string not in _KNOWN_UNITS so misconfigurations
    are surfaced rather than silently returning raw values that will be compared
    against incorrectly-scaled thresholds.
    """
    unit = (unit or "mbps").lower()
    if unit == "mbps":
        return (raw_val * 8) / (1024 * 1024)
    if unit == "kbps":
        return (raw_val * 8) / 1024
    if unit == "count":
        return raw_val
    # Unknown unit — return raw but warn so operators can fix the config.
    log.warning(
        "Unknown unit '%s' for metric '%s'; returning raw value. "
        "Expected one of: %s",
        unit,
        metric_name,
        ", ".join(sorted(_KNOWN_UNITS)),
    )
    return raw_val


# ---------------------------------------------------------------------------
# Status evaluation  (GREEN / YELLOW / RED / NO_DATA)
# ---------------------------------------------------------------------------
def evaluate(resource_data: list[dict], meta: dict) -> str:
    """
    Derive an aggregate status across all resources for a single metric + window.

    Rules (in priority order):
      1. No data at all        → NO_DATA  (GREEN for crc_error: absence = no errors)
      2. critical: true        → RED if any resource has value == 0
      3. threshold exceeded    → RED
      4. warning exceeded      → YELLOW
      5. Otherwise             → GREEN
    """
    if not resource_data:
        return "GREEN" if meta.get("is_crc_error") else "NO_DATA"

    agg        = meta.get("aggregation", "avg")
    unit       = meta.get("unit", "mbps")
    threshold  = meta.get("threshold")
    warning    = meta.get("warning")
    critical   = meta.get("critical", False)
    is_crc     = meta.get("is_crc_error", False)
    metric_name = meta.get("name", "")

    worst = "GREEN"

    for item in resource_data:
        raw_val = _pick_val(item, agg)
        val     = _convert(raw_val, unit, metric_name)

        # CRC errors: any non-zero = RED
        if is_crc:
            if val > 0:
                return "RED"
            continue

        # critical metrics (e.g. session_up): zero = failure
        if critical and val == 0:
            return "RED"

        # threshold breach
        if threshold is not None and val > threshold:
            return "RED"

        # warning breach
        if warning is not None and val > warning:
            worst = "YELLOW"

    return worst


# ---------------------------------------------------------------------------
# Format per-resource result
# ---------------------------------------------------------------------------
def _format_resource(item: dict, meta: dict) -> dict:
    agg        = meta.get("aggregation", "avg")
    unit       = meta.get("unit", "mbps")
    threshold  = meta.get("threshold")
    warning    = meta.get("warning")
    critical   = meta.get("critical", False)
    is_crc     = meta.get("is_crc_error", False)
    metric_name = meta.get("name", "")

    raw_val = _pick_val(item, agg)
    val     = _convert(raw_val, unit, metric_name)

    if is_crc:
        status = "RED" if val > 0 else "GREEN"
    elif critical and val == 0:
        status = "RED"
    elif threshold is not None and val > threshold:
        status = "RED"
    elif warning is not None and val > warning:
        # Fixed: warning range now correctly emits YELLOW at the row level,
        # consistent with the aggregate status returned by evaluate().
        status = "YELLOW"
    else:
        status = "GREEN"

    return {
        "resource": item["resource"],
        "value":    round(val, 2),
        "status":   status,
    }


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------
def _validate_project(project: dict) -> None:
    if not isinstance(project, dict):
        raise ValueError("Project entry must be a dict")
    if not project.get("project_id"):
        raise ValueError("Project entry missing 'project_id'")


def _validate_metrics(metrics: dict) -> None:
    if not isinstance(metrics, dict):
        raise ValueError("metrics must be a dict")
    for cat, mset in metrics.items():
        if not isinstance(mset, dict):
            raise ValueError(f"metrics.{cat} must be a dict")
        for name, meta in mset.items():
            if not meta.get("type"):
                raise ValueError(f"metrics.{cat}.{name} missing 'type'")
            if not meta.get("aggregation"):
                raise ValueError(f"metrics.{cat}.{name} missing 'aggregation'")


# ---------------------------------------------------------------------------
# Annotate meta with derived flags (called once per metric)
# ---------------------------------------------------------------------------
def _annotate_meta(name: str, meta: dict) -> dict:
    """Return a copy of meta with derived flags added."""
    m = dict(meta)
    m["is_crc_error"] = (name == "crc_error_count")
    m["name"] = name  # carried through for logging in _convert()
    return m


# ---------------------------------------------------------------------------
# Main project processor
# ---------------------------------------------------------------------------
def process_project(project: dict, metrics: dict, windows: dict) -> dict:
    """
    Collect all metrics for a single project across all windows.

    Returns:
        {
          "project_id": str,
          "metrics": { category: { metric_name: { window_label: { value, status } } } }
        }

    On credential or API error, returns the dict with an "error" key so the
    dashboard can surface it without crashing the whole run.
    """
    _validate_project(project)

    # Validate metrics config up front so a bad YAML produces a clear error
    # here rather than a cryptic KeyError deep inside fetch_metric().
    try:
        _validate_metrics(metrics)
    except ValueError as exc:
        log.error("Metrics config validation failed: %s", exc)
        return {
            "project_id": project.get("project_id", "unknown"),
            "error": str(exc),
            "metrics": {},
        }

    project_id = project["project_id"]
    log.info("Processing project: %s", project_id)

    try:
        client = build_client(project)
    except FileNotFoundError as exc:
        log.error("Project %s: service account key not found: %s", project_id, exc)
        return {"project_id": project_id, "error": str(exc), "metrics": {}}
    except ValueError as exc:
        log.error("Project %s: service account key malformed: %s", project_id, exc)
        return {"project_id": project_id, "error": str(exc), "metrics": {}}
    except google.auth.exceptions.DefaultCredentialsError as exc:
        log.error("Project %s: ADC not available: %s", project_id, exc)
        return {"project_id": project_id, "error": str(exc), "metrics": {}}
    except Exception as exc:
        log.error(
            "Project %s: unexpected error building client: %s",
            project_id, exc, exc_info=True,
        )
        return {"project_id": project_id, "error": str(exc), "metrics": {}}

    result: dict = {"project_id": project_id, "metrics": {}}

    for category, mset in metrics.items():
        result["metrics"][category] = {}

        for name, raw_meta in mset.items():
            meta = _annotate_meta(name, raw_meta)
            result["metrics"][category][name] = {}

            for window_label, window_seconds in windows.items():
                try:
                    resource_data = fetch_metric(
                        client, project_id, meta["type"], window_seconds
                    )
                except GoogleAPICallError as exc:
                    log.warning(
                        "Project %s | %s.%s | %s: API error: %s",
                        project_id, category, name, window_label, exc,
                    )
                    result["metrics"][category][name][window_label] = {
                        "value":  None,
                        "status": "NO_DATA",
                        "error":  str(exc),
                    }
                    continue
                except Exception as exc:
                    log.error(
                        "Project %s | %s.%s | %s: unexpected error: %s",
                        project_id, category, name, window_label, exc,
                        exc_info=True,
                    )
                    result["metrics"][category][name][window_label] = {
                        "value":  None,
                        "status": "NO_DATA",
                        "error":  str(exc),
                    }
                    continue

                status    = evaluate(resource_data, meta)
                formatted = [_format_resource(item, meta) for item in resource_data]

                result["metrics"][category][name][window_label] = {
                    "value":  formatted if formatted else None,
                    "status": status,
                }

                log.debug(
                    "Project %s | %s.%s | %s → %s (%d resources)",
                    project_id, category, name, window_label, status, len(formatted),
                )

    log.info("Finished project: %s", project_id)
    return result


# ---------------------------------------------------------------------------
# Module self-test (optional — run directly to sanity-check imports)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("gcp_metrics.py imported successfully — no direct entry point.")
    print("This module is called by main.yml via the Ansible 'script' or 'library' task.")
    sys.exit(0)
